package com.example.demo;

import java.util.List;
import java.util.Scanner;

public class BibliotecaController {
    private BibliotecaModel model;
    private Scanner scanner;

    // Construtor que inicializa o controller com o modelo e um scanner para entrada de dados
    public BibliotecaController(BibliotecaModel model) {
        this.model = model;
        this.scanner = new Scanner(System.in);
    }

    // Método para cadastrar um livro, solicitando dados do usuário via console
    public void cadastrarLivro() {
        System.out.println("Cadastro de Livro:");
        System.out.print("Título: ");
        String titulo = scanner.nextLine();
        System.out.print("Autor: ");
        String autor = scanner.nextLine();
        System.out.print("Ano de Publicação: ");
        int anoPublicacao = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Gênero: ");
        String genero = scanner.nextLine();
        
        model.cadastrarLivro(titulo, autor, anoPublicacao, genero);
    }

    // Método para listar todos os livros cadastrados
    public void listarLivros() {
        System.out.println("Lista de Livros:");
        List<String> livros = model.listarLivros();
        
        if (livros.isEmpty()) {
            System.out.println("Nenhum livro cadastrado.");
        } else {
            for (String livro : livros) {
                System.out.println(livro);
            }
        }
    }

    // Método para emprestar um livro
    public void emprestarLivro() {
        System.out.println("Emprestar Livro:");
        System.out.print("ID do Livro: ");
        int idLivro = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Nome do Usuário: ");
        String nomeUsuario = scanner.nextLine();
        
        boolean sucesso = model.emprestarLivro(idLivro, nomeUsuario);
        if (sucesso) {
            System.out.println("Livro emprestado com sucesso!");
        } else {
            System.out.println("Não foi possível emprestar o livro.");
        }
    }

    // Método para devolver um livro
    public void devolverLivro() {
        System.out.println("Devolver Livro:");
        System.out.print("ID do Livro: ");
        int idLivro = scanner.nextInt();
        scanner.nextLine();
        
        boolean sucesso = model.devolverLivro(idLivro);
        if (sucesso) {
            System.out.println("Livro devolvido com sucesso!");
        } else {
            System.out.println("Não foi possível devolver o livro.");
        }
    }
}
