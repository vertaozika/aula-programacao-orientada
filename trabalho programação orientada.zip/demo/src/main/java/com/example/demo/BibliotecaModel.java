package com.example.demo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BibliotecaModel {
    private final String jdbcURL = "jdbc:h2:mem:testdb";
    private final String username = "sa";
    private final String password = "password";
    private Connection connection;

    public BibliotecaModel() {
        try {
            connection = DriverManager.getConnection(jdbcURL, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para cadastrar um livro na base de dados
    public void cadastrarLivro(String titulo, String autor, int anoPublicacao, String genero) {
        try {
            String sql = "INSERT INTO livros (titulo, autor, ano_publicacao, genero) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, titulo);
            statement.setString(2, autor);
            statement.setInt(3, anoPublicacao);
            statement.setString(4, genero);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Livro cadastrado com sucesso!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os livros cadastrados na base de dados
    public List<String> listarLivros() {
        List<String> livros = new ArrayList<>();
        try {
            String sql = "SELECT * FROM livros";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String titulo = resultSet.getString("titulo");
                String autor = resultSet.getString("autor");
                int anoPublicacao = resultSet.getInt("ano_publicacao");
                String genero = resultSet.getString("genero");

                String bookInfo = String.format("ID: %d, Título: %s, Autor: %s, Ano de Publicação: %d, Gênero: %s",
                        id, titulo, autor, anoPublicacao, genero);
                livros.add(bookInfo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livros;
    }

    // Método para emprestar um livro
    public boolean emprestarLivro(int idLivro, String nomeUsuario) {
        try {
            String sql = "UPDATE livros SET emprestado = true, nome_usuario = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, nomeUsuario);
            statement.setInt(2, idLivro);
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Método para devolver um livro
    public boolean devolverLivro(int idLivro) {
        try {
            String sql = "UPDATE livros SET emprestado = false, nome_usuario = NULL WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, idLivro);
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
