package com.example.demo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException {
        BibliotecaModel model = new BibliotecaModel();
        BibliotecaController controller = new BibliotecaController(model);
        Scanner scanner = new Scanner(System.in);

        Class.forName("org.h2.Driver");
System.out.println("Driver JDBC do H2 carregado com sucesso!");

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Cadastrar Livro");
            System.out.println("2. Listar Livros");
            System.out.println("3. Emprestar Livro");
            System.out.println("4. Devolver Livro");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opcao: ");

            int choice = getIntInput(scanner);

            switch (choice) {
                case 1:
                    controller.cadastrarLivro();
                    break;
                case 2:
                    controller.listarLivros();
                    break;
                case 3:
                    controller.emprestarLivro();
                    break;
                case 4:
                    controller.devolverLivro();
                    break;
                case 5:
                    System.out.println("Saindo do programa...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opcao invalida. Por favor, escolha novamente.");
            }
        }
    }

    private static int getIntInput(Scanner scanner) {
        while (true) {
            try {
                if (scanner.hasNextInt()) {
                    return scanner.nextInt();
                } else {
                    String input = scanner.nextLine();
                    if (input.trim().equals("5")) {
                        return 5;
                    } else {
                        System.out.println("Entrada inválida. Por favor, digite um número.");
                    }
                }
            } catch (Exception e) {
                return 5; // Se ocorrer uma exceção, assumimos que o usuário quer sair
            }
        }
    }
}
